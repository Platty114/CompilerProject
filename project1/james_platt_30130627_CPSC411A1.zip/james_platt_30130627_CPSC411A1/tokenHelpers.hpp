#include <string>

//returns true if the given string is a key word in the c- language
bool isKeyword(std::string & string_to_compare);

bool isKeywordWithCasing(std::string & string_to_compare);

bool isSpecialChar(char & character);

